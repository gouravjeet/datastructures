#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include "customer.h"
Customer::Customer(){
	name="";
	num_movies=0;

}
Customer::Customer(std::string n,int num_m,std::list<std::string> & movies_l,std::list<std::string> & movies_pl){
	name=n;
	num_movies=num_m;
	movies_list=movies_l;
	preference_list=movies_pl;
	
}
	std::string Customer::get_name() const{
		return name;
	}
	int Customer::getNumMovies() const{
		return num_movies;
	}
	std::list<std::string> Customer::getMoviesList() const{
		return movies_list;
	}

bool Customer::has_max_num_movies(){
	
	return true;
}	

bool Customer::preference_list_empty(){
	if(movies_list.empty())
		return true;
	else 
		return false;
}

std::list<std::string> Customer::get_preferences() const{
	return preference_list;
}
void Customer::receives(std::string movie_receiv){

}