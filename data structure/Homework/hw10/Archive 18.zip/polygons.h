#include <iostream>
#include <vector>
#include "utilities.h"
class Polygon{
public:
	Polygon(const std::string &name, const std::vector<Point> &pts);
	const std::string & getName() const {return name;}
	virtual bool HasAllEqualSides(); 
	virtual bool HasAllEqualAngles();
	virtual bool HasARightAngle();
	virtual bool HasAnObtuseAngle();
	virtual bool HasAnAcuteAngle();
  virtual bool IsConvex();
	virtual bool IsConcave(){ return !IsConvex(); }

	

protected:
	
  std::vector<Point> vertices;
	std::string name;

};

class Triangle: public Polygon{
public:
	Triangle(const std::string &name, const std::vector<Point> &pts);
	 virtual bool HasAllEqualAngles() { return false; } 
	 virtual bool HasAllEqualSides() { return false; }
	 virtual bool HasARightAngle() { return false; }
	 virtual bool HasAnObtuseAngle() { return false; }
	 bool HasAnAcuteAngle() { return true; }
	  bool IsConvex() { return true; }
};
class RightTriangle:virtual public Triangle{
public:
	RightTriangle(const std::string &name, const std::vector<Point> &pts);  
   virtual bool HasARightAngle() { return true; } 
};
class IsoscelesTriangle : virtual public Triangle {
 public:
  IsoscelesTriangle(const std::string &name, const std::vector<Point> &pts);
};

  
class IsoscelesRightTriangle : public IsoscelesTriangle, public RightTriangle {
 public:
   IsoscelesRightTriangle(const std::string &name, const std::vector<Point> &pts);
};


class IsoscelesObtuseTriangle : public IsoscelesTriangle, public ObtuseTriangle {
 public:
  IsoscelesObtuseTriangle(const std::string &name, const std::vector<Point> &pts);
};

class ObtuseTriangle : virtual public Triangle {
 public:
  ObtuseTriangle(const std::string &name, const std::vector<Point> &pts);  
  virtual bool HasAnObtuseAngle() { return true; } 
};

class Quadrilateral : public Polygon {
 public:
  Quadrilateral(const std::string &name, const std::vector<Point> &pts);
  virtual bool HasAllEqualAngles() { return false; } 
  virtual bool HasAllEqualSides() { return false; } 
};

class EquilateralTriangle : public IsoscelesTriangle {
 public:
  EquilateralTriangle(const std::string &name, const std::vector<Point> &pts);
  virtual bool HasAllEqualSides() { return true; } 
  virtual bool HasAllEqualAngles() { return true; } 
  virtual bool HasARightAngle() { return false; } 

};



class Trapezoid : virtual public Quadrilateral {
 public:
  Trapezoid(const std::string &name, const std::vector<Point> &pts);
  virtual bool IsConvex() { return true; }
  virtual bool HasAnObtuseAngle() { return true; } 
};

class Kite : virtual public Quadrilateral {
 public:
  Kite(const std::string &name, const std::vector<Point> &pts);
  virtual bool IsConvex() { return true; }
};

class Arrow : public Quadrilateral {
 public:
  Arrow(const std::string &name, const std::vector<Point> &pts);
  virtual bool IsConvex() { return false; }
};


class Parallelogram : virtual public Trapezoid {
 public:
  Parallelogram(const std::string &name, const std::vector<Point> &pts);
  virtual bool HasARightAngle() { return false; } 
};
class Rhombus : virtual public Parallelogram, public Kite {
 public:
  Rhombus(const std::string &name, const std::vector<Point> &pts);
  virtual bool HasAllEqualSides() { return true; } 
  virtual bool HasARightAngle() { return false; } 
  virtual bool IsConvex() { return true; }
};

  class IsoscelesTrapezoid : virtual public Trapezoid {
 public:
  IsoscelesTrapezoid(const std::string &name, const std::vector<Point> &pts);
  virtual bool HasARightAngle() { return false; } 
};



class Rectangle : virtual public Parallelogram, public IsoscelesTrapezoid {
 public:
  Rectangle(const std::string &name, const std::vector<Point> &pts);
  virtual bool HasAllEqualAngles() { return true; } 
  virtual bool HasARightAngle() { return true; } 
  virtual bool HasAnObtuseAngle() { return false; }
};

class Square : public Rectangle, public Rhombus {
 public:
  Square(const std::string &name, const std::vector<Point> &pts);
  virtual bool HasARightAngle() { return true; }
};

