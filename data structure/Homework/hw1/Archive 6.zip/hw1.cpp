//This program will take input from a file and convert it into flush left and flush right and full justify

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <ctype.h>
#include <cstdlib>
using namespace std;
void flush_right(std::ifstream & in_str, std::vector<std::string> & input_vector,std::vector<std::string> & output_vector , std::ofstream & out_str, int count_var);
void flush_left(std::ifstream & in_str, std::vector<std::string> & input_vector,std::vector<std::string> & output_vector , std::ofstream & out_str, int count_var);
void full_justify(std::ifstream & in_str, std::vector<std::string> & input_vector,std::vector<std::string> & output_vector ,std::ofstream & out_str, int count_var);
int main(int argc, char* argv[]) {
 	
 	
 	std::string x;
 	std::ifstream in_str( argv[1]);
 	if(!in_str.good()){
 		std::cerr <<"Can't open " << argv[1] <<"to read.\n";
 		std::exit(1);
 	}
 	
 	std::ofstream out_str(argv[2]);
  	if (!out_str.good()) {
    std::cerr << "Can't open " << argv[2] << " to write.\n";
    std::exit(1);
  	}
  	std::vector<std::string> output_vector;
  	std::vector <std::string> input_vector;
  	while(in_str >> x){
 	
 	input_vector.push_back(x);
 	
 	}
 	
  	for(int r=0;r<output_vector.size();r++)
  	{
  		out_str<<output_vector[r];
  	}
  	
	int count1= std::atoi(argv[3]); 
	
  	//std::cin>>count_var;
  	std::string function_called=argv[4];
  	if(function_called=="flush_left")
  	{
  		flush_left(in_str,input_vector,output_vector, out_str, count1);
  	}
  	else if (function_called=="flush_right")
  	{
  		flush_right(in_str,input_vector,output_vector, out_str, count1);
  	}
  	 else if(function_called=="full_justify")
  	 {
  	 	full_justify(in_str,input_vector,output_vector, out_str, count1);
  	 } 

  	//convert_flush_right(in_str,input_vector,output_vector, out_str, count1);
  	  //flush_left(in_str,input_vector,output_vector, out_str, count1);
  	
  	
}
 
/* This program will make text to the flush right 
This is taking vector , input stream , count variable as input and is aligning the text to flush right*/
void flush_right(std::ifstream & in_str, std::vector<std::string> & input_vector,std::vector<std::string> & output_vector ,std::ofstream & out_str, int count_var){

	std::string line="";
	int count=count_var;
	
for(int i=0;i<count_var+4;i++)
 	{
 	out_str<<"-";	
 	}
 	out_str<< std::endl;
	out_str<<"| ";

	for(int i=0;i<input_vector.size();i++)
	{
		//std::cout<<"*"<<input_vector[i]<<"*";
		if(count>0 && count>=(input_vector[i].size()+1))
  		{ 	
 				if(count==count_var)
 				{
 				line.append(input_vector[i]);
 				count=count-(input_vector[i].size());
 				}
 				else
 				{
 				line.append(" ").append(input_vector[i]);
 				count=count-(input_vector[i].size())-1;
 				}
 				
 		//std::cout<<line<<"()"<<count;
 		//cout<<count<<" ";
 		//std::cout<<" "<< x;
 		}
 		else 
 		{
 			int dup_size=0;	
 			for(int k=i-1;k>=0;k--)
 			{
 			dup_size=dup_size + input_vector[k].size() ;
 			//std::cout<<input_vector[k].size()<<std::endl;
 			}
 		
 			//std::cout<<"!"<<dup_size;
 			//if(line.size()==)
 			for(int j=0;j<count;j++)
 			{
 			out_str<<" ";
 			}
 			//cout<<line;
 			out_str<<line;
 			line="";
 			out_str<<" |";
 			out_str<<std::endl;
 			count=count_var;
 			out_str<<"| ";
 			
 			if(count==count_var)
 			{
 			line.append(input_vector[i]);
 			count=count-input_vector[i].size();
 			//std::cout<<"$"<<line;
			}
 			else
 			{
 			line.append(" ").append(input_vector[i]);
 			count=count-input_vector[i].size()-1;
 			//std::cout<<"$#"<<line;
 			}
 		}
	} 	
 	for(unsigned int i=0;i<count;i++)
 		{
 		out_str<<" ";
 		}
 	out_str<<line;	
 	out_str<<" "<<"|";
 	out_str<<std::endl;
 	for(int i=0;i<count_var+4;i++)
 	{
 	out_str<<"-";
 		
 	}
 	out_str<< std::endl;
}
/* This program will make text to the full justify
This is taking vector , input stream , count variable as input and is aligning the text to full justify*/


/* This program will make text to the flush left 
This is taking vector , input stream , count variable as input and is aligning the text to flush left*/
void full_justify(std::ifstream & in_str, std::vector<std::string> & input_vector,std::vector<std::string> & output_vector ,std::ofstream & out_str, int count_var){

	std::string line=" ";
	std::string outputstring="";
	std::vector <std::string> vect;
	std::vector <std::string> temp;
 	std::vector<std::string> final_vect;
 	int spaceadd;
	int count=count_var;
	int words_in_line=0;

for(int i=0;i<count_var+4;i++)
 	{
 	out_str<<"-";	
 	}
 	out_str<< std::endl;
	out_str<<"| ";

	for(unsigned int i=0;i<input_vector.size();i++)
	{
		//std::cout<<"*"<<input_vector[i]<<"*";
		if(count>0 && count>=(input_vector[i].size()+1))
  		{ 	
 				
 				if(count==count_var)
 				{
 				line.append(input_vector[i]);
 				count=count-(input_vector[i].size());
 				words_in_line=words_in_line+1;
 				//std::cout<<words_in_line;
 				}
 				else
 				{
 				line.append(" ").append(input_vector[i]);
 				count=count-(input_vector[i].size())-1;
 				words_in_line=words_in_line+1;
 				}
 				
 		
 		}
 		else 
 		{
 			
 			vect.push_back(line);
 			//std::cout<<count;
 			
 			if(words_in_line==1)
 			{

 			}
 			else
 			{
 			spaceadd=count/(words_in_line-1);
 			std::cout<<spaceadd;
 			}
 			for(unsigned int c=0;c<=vect.size()-1;c++)
 			{
 				if(vect[c]==" ")
 				{
 					for(unsigned int u=0;u<c;u++)
 					{
 						temp[u]=vect[u];
 						for(int f=0;f<=spaceadd;f++)
 						{
 							temp.push_back(" ");
 						}
 					}
 				}
 				for(unsigned int c=0;c<temp.size();c++)
 				{
 					final_vect[final_vect.size()+c]=temp[c];
 				}
 			}
 			/*for(int g=0;g<final_vect.size()-1;g++)
 			{
 			outputstring.append(final_vect[g]);	
 			}*/		
 			std::cout<<outputstring;
 			out_str<<outputstring;
 			line="";
 			out_str<<" |";
 			out_str<<std::endl;
 			count=count_var;
 			out_str<<"| ";
 			words_in_line=0;
 			if(count==count_var)
 			{
 			line.append(input_vector[i]);
 			count=count-input_vector[i].size();
 			words_in_line=words_in_line+1;
 			//std::cout<<"$"<<line;
			}
 			else
 			{
 			line.append(" ").append(input_vector[i]);
 			count=count-input_vector[i].size()-1;
 			words_in_line=words_in_line+1;
 			//std::cout<<"$#"<<line;
 			}
 		}
	} 	
 			vect.push_back(line);
 			if(words_in_line==1)
 			{

 			}
 			else
 			{
 			spaceadd=count/(words_in_line-1);
 			}
 			
 			for(unsigned int c=0;c<=vect.size();c++)
 			{
 				if(vect[c]==" ")
 				{
 					for(unsigned int u=0;u<c;u++)
 					{
 						temp[u]=vect[u];
 						for(unsigned int f=0;f<=spaceadd;f++)
 						{
 							temp.push_back(" ");
 						}
 					}
 				}
 				for(unsigned int c=0;c<temp.size();c++)
 				{
 					final_vect[final_vect.size()+c]=temp[c];
 				}
 			}
 	for(unsigned int g=0;g<final_vect.size();g++)
 	{
 		std::cout<<final_vect[g];
 	//outputstring.append(final_vect[g]);	
 	}		
 	std::cout<<outputstring;
 	out_str<<outputstring;

 	out_str<<" "<<"|";
 	out_str<<std::endl;
 	for(int i=0;i<count_var+4;i++)
 	{
 	out_str<<"-";
 		
 	}
 	out_str<< std::endl;
}
void flush_left(std::ifstream & in_str, std::vector<std::string> & input_vector,std::vector<std::string> & output_vector ,std::ofstream & out_str, int count_var){

	std::string line="";
	int count=count_var;
	for(int i=0;i<count_var+4;i++)
 	{
 	out_str<<"-";	
 	}
 	out_str<< std::endl;
	out_str<<"| ";

	for(unsigned int i=0;i<input_vector.size();i++)
	{
		//std::cout<<"*"<<input_vector[i]<<"*";
		if(input_vector[i].size()>16)
		{
			
			std::string s1;
			std::string s2;
			std::string s4;
			std::string s3=input_vector[i];
			//std::int length_long=input_vector[i].size();
			//std::int x=(length_long/count_var);
			s1=s3.substr(0,15);
			s2=s3.substr(15,29);
			s4=s3.substr(29,44);
			out_str<< s1<<"- |"<<std::endl<<"| ";
			out_str<< s2<<"- |"<<std::endl<<"| ";
			out_str<< s4<<"       |"<<std::endl;

		}
		if(count>0 && count>=(input_vector[i].size()+1))
  		{ 	
 				if(count==count_var)
 				{
 				line.append(input_vector[i]);
 				count=count-(input_vector[i].size());
 				}
 				else
 				{
 				line.append(" ").append(input_vector[i]);
 				count=count-(input_vector[i].size())-1;
 				}
 				
 		//std::cout<<line<<"()"<<count;
 		//cout<<count<<" ";
 		//std::cout<<" "<< x;
 		}
 		
 		else 
 		{
 			int dup_size=0;	
 			for(int k=i-1;k>=0;k--)
 			{
 			dup_size=dup_size + input_vector[k].size() ;
 			//std::cout<<input_vector[k].size()<<std::endl;
 			}
 		
 			out_str<<line;
 			for(int j=0;j<count;j++)
 			{
 			out_str<<" ";
 			}
 			line="";
 			out_str<<" |";
 			out_str<<std::endl;
 			count=count_var;
 			out_str<<"| ";
 			
 			if(count==count_var)
 			{
 			line.append(input_vector[i]);
 			count=count-input_vector[i].size();
 			//std::cout<<"$"<<line;
			}
 			else
 			{
 			line.append(" ").append(input_vector[i]);
 			count=count-input_vector[i].size()-1;
 			//std::cout<<"$#"<<line;
 			}
 		}
	} 	
 	
 	out_str<<line;	
 	for(unsigned int i=0;i<count;i++)
 		{
 		out_str<<" ";
 		}
 	out_str<<" "<<"|";
 	out_str<<std::endl;
 	for(unsigned int i=0;i<count_var+4;i++)
 	{
 	out_str<<"-";
 		
 	}
 	out_str<< std::endl;
}
