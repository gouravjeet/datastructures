HOMEWORK 8: FRIENDLY RECURSION


NAME:  < Gouravjeet Singh>


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Chetan, Aayush, Krishna, Google, Yuvraj>

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 20 >



NETWORK COMPLEXITY
Analysis of the maximum number of people at a party with chain
length n, if each person has at most k friends.
		O(n^k)

YOUR NEW TEST CASES
Submitted as an input file named my_input.txt.  Briefly describe how
this test exercises the corner cases of your implementation.  Why is
this test case interesting and/or challenging?

Add friendship that exists
Add a message twice
Print invitation list of person that doesnot exists


EXTRA CREDIT
Describe your (optional) implementation of the telephone game.


MISC. COMMENTS TO GRADER:  
Optional, please be concise!






