#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include "graph.h"
#include "person.h"
#include "message.h"
#include "MersenneTwister.h"
Graph::Graph(){

};
Graph::~Graph(){

}

Person* Graph::find_person(const std::string &name) const{
	for (std::vector<Person*>::const_iterator p = m_people.begin(); p != m_people.end(); ++p){
		if((*p)->get_name()==name){
			
			return *p;
		}
	}
	return NULL;
}
bool Graph::add_person(const std::string& person_name){
	for (std::vector<Person*>::const_iterator p = m_people.begin(); p != m_people.end(); ++p){
		if((*p)->get_name()==person_name){
			return false;
		}
	}		
			Person* p=new Person(person_name);
			m_people.push_back(p);
			return true;	
	
	
}
bool Graph::remove_person(const std::string& person_name){
	for (std::vector<Person*>::const_iterator p1 = m_people.begin(); p1 != m_people.end(); ++p1){
		if((*p1)->get_name()==person_name){
			m_people.erase(p1);
			return true;
		}
	}
	return false;
}
bool Graph::add_friendship(const std::string& person_name1, const std::string& person_name2){
	if(find_person(person_name1) && find_person(person_name2) ){
		Person* Person1 =find_person(person_name1);
		Person* Person2 =find_person(person_name2);	
		if(Person1->is_friend(Person2)){
			return false;
		}
		return Person1->add_friend(Person2);
			
	}
	return false;
}
bool Graph::remove_friendship(const std::string& person_name1, const std::string& person_name2){
	if(find_person(person_name1) && find_person(person_name2) ){
		Person* Person1 =find_person(person_name1);
		Person* Person2 =find_person(person_name2);	
		if(Person1->is_friend(Person2)){
			return Person1->remove_friend(Person2);	
		
		}
		return false;
	}
	return false;
}
bool Graph::add_message(const std::string& person_name, const std::string& message){
	if(find_person(person_name)){
		Person* Person1 =find_person(person_name);
		Message* m=new Message(message,Person1);
		m_messages.push_back(m);
		return Person1->add_message(m);
			
	}
	else 
		return false;
}
void Graph::pass_messages(MTRand &mtrand){
	

	for (std::vector<Person*>::const_iterator p2 = m_people.begin(); p2 != m_people.end(); ++p2){
		std::list<Person*> friends=((*p2)->get_friends());
		std::list<Message*> messages_lst=((*p2)->get_messages());

		for (std::list<Message *>::const_iterator it1 = messages_lst.begin(); it1 != messages_lst.end(); ++it1){

					int random_num=mtrand.randInt(friends.size());
					std::cout<<"random number generated"<<random_num;
					// find the random number from the friends list and send the message to that number	
					std::list<Person*>::const_iterator it3=friends.begin();
					for(int i=0;i<random_num-1;i++){
						it3++;
					}
					Person* p1=*it3;
					std::string pers=p1->get_name();
					const std::string z=((*it1)->get_message());
					// we need to add the message into the graph also and that will call message of person.
					// We need to change the owner of the function also
					bool a=add_message(pers,z);
					bool b=((*p2)->remove_message(*it1));
					//continue;
		}			
	}
	
}
void Graph::print(std::ostream &ostr) const{
		for (std::vector<Person*>::const_iterator p = m_people.begin(); p != m_people.end(); ++p){
			ostr<<((*p)->get_name())<<std::endl;
			ostr<<"  friends: ";
			std::list<Person*> m_fr=((*p)->get_friends());
			for (std::list<Person*>::const_iterator it2 = m_fr.begin(); it2 != m_fr.end(); ++it2){
				ostr<<((*it2)->get_name())<<" ";
			}
			ostr<<std::endl;
			ostr<<"  messages: ";
			std::list<Message*> msg=((*p)->get_messages());
			for (std::list<Message *>::const_iterator it1 = msg.begin(); it1 != msg.end(); ++it1){
				ostr<<((*it1)->get_message())<<" ";
			}
			ostr<<std::endl;
		}
		ostr<<std::endl<<std::endl;
}
bool Graph::print_invite_list(std::ostream &ostr, const std::string &name, int n) const{
	return true;
} 